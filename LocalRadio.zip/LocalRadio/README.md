# LocalRadio

Transformez votre téléphone Android en mini radio locale : il diffuse ses fichiers
audio en direct à tous les appareils connectés au même réseau Wi-Fi (téléphones,
tablettes, PC), via une simple adresse web ou un QR code.

## Fonctionnement technique (résumé)

- **Aucune dépendance réseau tierce** : le serveur web est écrit à la main en
  Kotlin avec `java.net.ServerSocket` (fichier `WebServer.kt`).
- **Diffusion en direct réelle** : `RadioService` lit la playlist en boucle,
  fichier par fichier, et pousse les mêmes octets audio, au même rythme, à tous
  les auditeurs connectés simultanément (`/stream`) — comme une vraie radio.
- **Page web du lecteur** intégrée (`PlayerPage.kt`) : nom de la station,
  morceau en cours, lecture/pause, volume, barre de progression — mise à jour
  chaque seconde via `/status` (JSON).
- **QR code** généré avec la bibliothèque ZXing (seule dépendance tierce du
  projet, uniquement pour l'encodage QR).
- **IP locale détectée automatiquement** (Wi-Fi) et mise à jour en direct si
  elle change ; le QR code et l'adresse affichée se régénèrent alors seuls.
- **Diffusion écran éteint** : service en avant-plan (foreground) +
  `WakeLock` partiel + `WifiLock` pour continuer à émettre quand l'écran
  s'éteint (dans la limite de ce qu'Android autorise).

## Compiler l'APK

Ce projet est un projet Android Studio standard (Kotlin, sans Compose).

### Option A — Android Studio (recommandé)
1. Ouvrez le dossier `LocalRadio/` avec Android Studio (Hedgehog ou plus
   récent).
2. Laissez Android Studio synchroniser Gradle (il régénère automatiquement le
   wrapper `gradlew` si besoin).
3. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. L'APK se trouve dans `app/build/outputs/apk/debug/app-debug.apk`.

### Option B — GitHub Actions (compilation automatique dans le cloud)
Un workflow est déjà inclus : `.github/workflows/build.yml`.
1. Créez un dépôt GitHub et poussez ce projet dedans.
2. L'action se lance automatiquement (ou lancez-la manuellement depuis
   l'onglet **Actions** → **Build LocalRadio APK** → **Run workflow**).
3. Téléchargez l'APK généré dans l'onglet **Artifacts** de l'exécution.

## Utilisation

1. Ouvrez l'application, appuyez sur **Ajouter des morceaux** et sélectionnez
   vos fichiers audio (mp3 recommandé pour une compatibilité maximale entre
   navigateurs).
2. Appuyez sur **Démarrer la radio**.
3. Sur un autre appareil connecté au **même réseau Wi-Fi**, scannez le QR code
   affiché ou entrez l'adresse indiquée (ex. `http://192.168.1.25:8080`) dans
   un navigateur.
4. La lecture, le volume et la progression se pilotent depuis la page web ;
   le morceau affiché se met à jour automatiquement chez tous les auditeurs.

## Limites connues

- Pour un rendu fluide entre navigateurs, utilisez des fichiers dans un même
  format (mp3 recommandé) : le flux `/stream` est une diffusion continue,
  changer de codec en cours de route peut perturber certains lecteurs.
- Le calage temporel du direct est basé sur la durée réelle du fichier
  (métadonnées) ; en cas de fichier sans métadonnées exploitables, un débit
  moyen de 128 kbps est supposé.
- Le nombre d'auditeurs simultanés dépend des capacités du téléphone hôte et
  du point d'accès Wi-Fi.
