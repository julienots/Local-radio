# LocalRadio

Transformez votre téléphone Android en mini radio locale : il diffuse ses fichiers
audio en direct à tous les appareils connectés au même réseau Wi-Fi (téléphones,
tablettes, PC), via une simple adresse web ou un QR code.

## Fonctionnement technique (résumé)

- **Aucune dépendance réseau tierce** : le serveur web est écrit à la main en
  Kotlin avec `java.net.ServerSocket` (fichier `WebServer.kt`).
- **Diffusion en direct réelle** : `RadioService` lit la playlist en boucle,
  fichier par fichier, et pousse les mêmes octets audio, au même rythme, à tous
  les auditeurs connectés simultanément (`/stream`) — comme une vraie radio.
- **Page web du lecteur** intégrée (`PlayerPage.kt`) : nom de la station,
  morceau en cours, lecture/pause, volume, barre de progression — mise à jour
  chaque seconde via `/status` (JSON).
- **QR code** généré avec la bibliothèque ZXing (seule dépendance tierce du
  projet, uniquement pour l'encodage QR).
- **IP locale détectée automatiquement** (Wi-Fi) et mise à jour en direct si
  elle change ; le QR code et l'adresse affichée se régénèrent alors seuls.
- **Diffusion écran éteint** : service en avant-plan (foreground) +
  `WakeLock` partiel + `WifiLock` pour continuer à émettre quand l'écran
  s'éteint (dans la limite de ce qu'Android autorise).

## Compiler l'APK

Ce projet est un projet Android Studio standard (Kotlin, sans Compose).

### Option A — Android Studio (recommandé)
1. Ouvrez le dossier `LocalRadio/` avec Android Studio (Hedgehog ou plus
   récent).
2. Laissez Android Studio synchroniser Gradle (il régénère automatiquement le
   wrapper `gradlew` si besoin).
3. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. L'APK se trouve dans `app/build/outputs/apk/debug/app-debug.apk`.

### Option B — GitHub Actions (compilation automatique dans le cloud)
Un workflow est déjà inclus : `.github/workflows/build.yml`.
1. Créez un dépôt GitHub et poussez ce projet dedans.
2. L'action se lance automatiquement (ou lancez-la manuellement depuis
   l'onglet **Actions** → **Build LocalRadio APK** → **Run workflow**).
3. Téléchargez l'APK généré dans l'onglet **Artifacts** de l'exécution.

## Utilisation

1. Ouvrez l'application, appuyez sur **Ajouter des morceaux** et sélectionnez
   vos fichiers audio (mp3 recommandé pour une compatibilité maximale entre
   navigateurs).
2. Appuyez sur **Démarrer la radio**.
3. Sur un autre appareil connecté au **même réseau Wi-Fi**, scannez le QR code
   affiché ou entrez l'adresse indiquée (ex. `http://192.168.1.25:8080`) dans
   un navigateur.
4. La lecture, le volume et la progression se pilotent depuis la page web ;
   le morceau affiché se met à jour automatiquement chez tous les auditeurs.

## Diffuser au-delà du Wi-Fi local (Internet)

Par défaut, `/stream` n'est joignable que par les appareils connectés au même
réseau Wi-Fi que le téléphone hôte (adresse `192.168.x.x` par ex.). Pour
qu'un auditeur extérieur (4G, autre Wi-Fi, autre pays) puisse écouter, il
faut un **tunnel** qui expose ce serveur local sur une adresse publique.

> Pourquoi pas un SDK ngrok intégré directement dans l'app ? Les SDK
> officiels ngrok ("Agent SDKs") ne couvrent aujourd'hui que Go,
> JavaScript, Python et Rust ; la version Java est en alpha et n'est pas
> conçue pour tourner nativement sur Android (bibliothèques natives pour
> postes de travail, pas pour l'ABI Android). L'intégrer aurait pu ne
> simplement pas fonctionner sur le téléphone. La solution ci-dessous
> utilise le véritable agent ngrok, en dehors de l'app, ce qui est fiable
> et ne demande aucune dépendance supplémentaire dans le projet.

### Avec ngrok, via Termux (sur le téléphone lui-même)

1. Installez **Termux** (F-Droid ou GitHub, éviter la version Play Store
   obsolète).
2. Dans Termux :
   ```
   pkg install wget
   wget https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-arm64.tgz
   tar -xvzf ngrok-v3-stable-linux-arm64.tgz
   ./ngrok config add-authtoken VOTRE_TOKEN
   ```
   (Le token gratuit s'obtient sur le tableau de bord ngrok, après
   inscription.)
3. Démarrez la radio dans LocalRadio, notez le port utilisé (8080 par
   défaut), puis dans Termux :
   ```
   ./ngrok http 8080
   ```
4. ngrok affiche une adresse du type `https://xxxx.ngrok-free.app`.
   Copiez-la dans le champ **« Diffusion sur Internet »** de l'app :
   elle génère alors une adresse et un QR code dédiés, partageables avec
   n'importe qui, où qu'il soit.
5. Gardez Termux ouvert (en arrière-plan) tant que vous voulez rester
   joignable depuis Internet ; l'adresse change à chaque redémarrage du
   tunnel sur le plan gratuit.

### Alternative : tunnel lancé depuis un PC/Mac

Si vous préférez ne pas installer Termux, vous pouvez lancer `ngrok http
<ip-locale>:<port>` (ex. `ngrok http 192.168.1.25:8080`) depuis un
ordinateur connecté au même Wi-Fi que le téléphone — cela fonctionne tant
que l'ordinateur reste allumé et sur le même réseau.

## Limites connues

- Pour un rendu fluide entre navigateurs, utilisez des fichiers dans un même
  format (mp3 recommandé) : le flux `/stream` est une diffusion continue,
  changer de codec en cours de route peut perturber certains lecteurs.
- Le calage temporel du direct est basé sur la durée réelle du fichier
  (métadonnées) ; en cas de fichier sans métadonnées exploitables, un débit
  moyen de 128 kbps est supposé.
- Le nombre d'auditeurs simultanés dépend des capacités du téléphone hôte et
  du point d'accès Wi-Fi.
- Sur le plan gratuit ngrok, l'adresse publique change à chaque redémarrage
  du tunnel : il faut la remettre à jour dans la carte « Diffusion sur
  Internet » après chaque coupure.
