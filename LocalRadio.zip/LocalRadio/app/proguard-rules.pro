# Ce projet compile avec isMinifyEnabled = false par défaut.
# Ajoutez vos règles ici si vous activez la minification.
