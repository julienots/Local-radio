package com.localradio.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var btnToggleRadio: android.widget.Button
    private lateinit var btnVoice: android.widget.Button
    private lateinit var btnAddTrack: android.widget.Button
    private lateinit var btnCopy: android.widget.Button
    private lateinit var btnShare: android.widget.Button
    private lateinit var etPort: android.widget.EditText
    private lateinit var tvAddress: TextView
    private lateinit var tvCurrentTrack: TextView
    private lateinit var tvListenerCount: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvEmptyPlaylist: TextView
    private lateinit var viewStatusDot: View
    private lateinit var progressTrack: ProgressBar
    private lateinit var imgQrCode: ImageView
    private lateinit var recyclerPlaylist: RecyclerView

    private lateinit var etPublicUrl: android.widget.EditText
    private lateinit var btnSavePublicUrl: android.widget.Button
    private lateinit var tvNoPublicUrl: TextView
    private lateinit var groupPublicAddress: View
    private lateinit var tvPublicAddress: TextView
    private lateinit var btnCopyPublic: android.widget.Button
    private lateinit var btnSharePublic: android.widget.Button
    private lateinit var imgQrCodePublic: ImageView

    private lateinit var adapter: PlaylistAdapter

    private val uiHandler = Handler(Looper.getMainLooper())
    private var lastRenderedAddress: String? = null
    private var isPolling = false

    private val pickAudioLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: Exception) { /* pas bloquant, le fichier est copié juste après */ }
                PlaylistManager.addTrackFromUri(this, uri)
            }
            refreshPlaylist()
            Toast.makeText(this, "${uris.size} morceau(x) ajouté(s)", Toast.LENGTH_SHORT).show()
        }
    }

    private val microphonePermissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startOrStopVoice() else Toast.makeText(this, "Autorisez le micro pour parler en direct", Toast.LENGTH_SHORT).show()
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { /* ignoré : la notification de diffusion reste utile mais pas bloquante */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        setupPlaylist()
        setupListeners()
        requestNotificationPermissionIfNeeded()

        etPort.setText(PlaylistManager.getPort(this).toString())
        etPublicUrl.setText(PlaylistManager.getPublicUrl(this))
        renderPublicAddress()
    }

    override fun onResume() {
        super.onResume()
        refreshPlaylist()
        startPolling()
    }

    override fun onPause() {
        super.onPause()
        isPolling = false
    }

    private fun bindViews() {
        btnToggleRadio = findViewById(R.id.btnToggleRadio)
        btnVoice = findViewById(R.id.btnVoice)
        btnAddTrack = findViewById(R.id.btnAddTrack)
        btnCopy = findViewById(R.id.btnCopy)
        btnShare = findViewById(R.id.btnShare)
        etPort = findViewById(R.id.etPort)
        tvAddress = findViewById(R.id.tvAddress)
        tvCurrentTrack = findViewById(R.id.tvCurrentTrack)
        tvListenerCount = findViewById(R.id.tvListenerCount)
        tvStatus = findViewById(R.id.tvStatus)
        tvEmptyPlaylist = findViewById(R.id.tvEmptyPlaylist)
        viewStatusDot = findViewById(R.id.viewStatusDot)
        progressTrack = findViewById(R.id.progressTrack)
        imgQrCode = findViewById(R.id.imgQrCode)
        recyclerPlaylist = findViewById(R.id.recyclerPlaylist)

        etPublicUrl = findViewById(R.id.etPublicUrl)
        btnSavePublicUrl = findViewById(R.id.btnSavePublicUrl)
        tvNoPublicUrl = findViewById(R.id.tvNoPublicUrl)
        groupPublicAddress = findViewById(R.id.groupPublicAddress)
        tvPublicAddress = findViewById(R.id.tvPublicAddress)
        btnCopyPublic = findViewById(R.id.btnCopyPublic)
        btnSharePublic = findViewById(R.id.btnSharePublic)
        imgQrCodePublic = findViewById(R.id.imgQrCodePublic)
    }

    private fun setupPlaylist() {
        adapter = PlaylistAdapter(emptyList()) { track ->
            PlaylistManager.removeTrack(this, track.id)
            refreshPlaylist()
        }
        recyclerPlaylist.layoutManager = LinearLayoutManager(this)
        recyclerPlaylist.adapter = adapter
    }

    private fun setupListeners() {
        btnToggleRadio.setOnClickListener {
            if (RadioState.isRunning) {
                stopRadio()
            } else {
                startRadio()
            }
        }

        btnVoice.setOnClickListener {
            if (!RadioState.isRunning) {
                Toast.makeText(this, "Démarrez d'abord la radio", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                microphonePermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
            } else {
                startOrStopVoice()
            }
        }

        btnAddTrack.setOnClickListener {
            pickAudioLauncher.launch(arrayOf("audio/*"))
        }

        btnCopy.setOnClickListener {
            val address = currentAddress()
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Adresse LocalRadio", address))
            Toast.makeText(this, "Adresse copiée", Toast.LENGTH_SHORT).show()
        }

        btnShare.setOnClickListener {
            val address = currentAddress()
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "Écoutez ma radio en direct : $address")
            }
            startActivity(Intent.createChooser(intent, "Partager l'adresse de la radio"))
        }

        btnSavePublicUrl.setOnClickListener {
            val raw = etPublicUrl.text.toString().trim()
            val normalized = normalizePublicUrl(raw)
            if (normalized == null) {
                Toast.makeText(this, "Adresse invalide (attendu : https://…)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            etPublicUrl.setText(normalized)
            PlaylistManager.setPublicUrl(this, normalized)
            renderPublicAddress()
            Toast.makeText(this, "Adresse Internet enregistrée", Toast.LENGTH_SHORT).show()
        }

        btnCopyPublic.setOnClickListener {
            val address = PlaylistManager.getPublicUrl(this)
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Adresse LocalRadio (Internet)", address))
            Toast.makeText(this, "Adresse copiée", Toast.LENGTH_SHORT).show()
        }

        btnSharePublic.setOnClickListener {
            val address = PlaylistManager.getPublicUrl(this)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "Écoutez ma radio en direct : $address")
            }
            startActivity(Intent.createChooser(intent, "Partager l'adresse de la radio"))
        }
    }

    /** Accepte une URL http(s) telle que collée depuis ngrok, avec ou sans slash final. */
    private fun normalizePublicUrl(raw: String): String? {
        if (raw.isEmpty()) return ""
        val candidate = if (raw.startsWith("http://") || raw.startsWith("https://")) raw else "https://$raw"
        return try {
            val uri = Uri.parse(candidate)
            if (uri.host.isNullOrEmpty()) null else candidate.trimEnd('/')
        } catch (e: Exception) {
            null
        }
    }

    private fun renderPublicAddress() {
        val url = PlaylistManager.getPublicUrl(this)
        if (url.isEmpty()) {
            tvNoPublicUrl.visibility = View.VISIBLE
            groupPublicAddress.visibility = View.GONE
        } else {
            tvNoPublicUrl.visibility = View.GONE
            groupPublicAddress.visibility = View.VISIBLE
            tvPublicAddress.text = url
            imgQrCodePublic.setImageBitmap(QrCodeGenerator.generate(url))
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this, android.Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun startOrStopVoice() {
        if (RadioState.isVoiceLive) {
            RadioService.stopVoice(this)
            Toast.makeText(this, "Micro coupé", Toast.LENGTH_SHORT).show()
        } else {
            RadioService.startVoice(this)
            Toast.makeText(this, "Vous êtes en direct 🎙️", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startRadio() {
        val playlist = PlaylistManager.load(this)
        if (playlist.isEmpty()) {
            Toast.makeText(this, "Ajoutez au moins un morceau avant de démarrer", Toast.LENGTH_SHORT).show()
            return
        }
        val port = etPort.text.toString().toIntOrNull() ?: 8080
        PlaylistManager.setPort(this, port)
        etPort.isEnabled = false

        RadioService.start(this, port)
        Toast.makeText(this, "Radio en cours de démarrage…", Toast.LENGTH_SHORT).show()
    }

    private fun stopRadio() {
        RadioService.stop(this)
        etPort.isEnabled = true
    }

    private fun refreshPlaylist() {
        val playlist = PlaylistManager.load(this)
        adapter.updateTracks(playlist)
        tvEmptyPlaylist.visibility = if (playlist.isEmpty()) View.VISIBLE else View.GONE
        recyclerPlaylist.visibility = if (playlist.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun currentAddress(): String {
        val ip = RadioState.localIp.ifEmpty { NetworkUtils.getLocalIpAddress(this) ?: "0.0.0.0" }
        val port = if (RadioState.isRunning) RadioState.port else
            (etPort.text.toString().toIntOrNull() ?: 8080)
        return "http://$ip:$port"
    }

    /** Boucle de rafraîchissement légère de l'UI : lit RadioState + l'IP courante toutes les secondes. */
    private fun startPolling() {
        isPolling = true
        uiHandler.post(object : Runnable {
            override fun run() {
                if (!isPolling) return
                renderState()
                uiHandler.postDelayed(this, 1000)
            }
        })
    }

    private fun renderState() {
        val running = RadioState.isRunning
        btnToggleRadio.text = if (running) getString(R.string.stop_radio) else getString(R.string.start_radio)
        btnVoice.text = if (RadioState.isVoiceLive) getString(R.string.stop_voice) else getString(R.string.start_voice)
        btnVoice.isEnabled = running
        btnToggleRadio.setBackgroundResource(if (running) R.drawable.bg_button_danger else R.drawable.bg_button_primary)

        tvStatus.text = if (running) "EN DIRECT" else "HORS LIGNE"
        viewStatusDot.alpha = if (running) 1f else 0.3f

        tvCurrentTrack.text = if (running) RadioState.currentTrackName else getString(R.string.no_track)
        adapter.updateCurrentlyPlaying(if (running) RadioState.currentTrackName else null)

        val listeners = RadioState.listenerCount
        tvListenerCount.text = "$listeners ${getString(R.string.listeners_label)}"

        val duration = RadioState.durationMs.coerceAtLeast(1)
        val position = RadioState.positionMs.coerceAtMost(duration)
        progressTrack.progress = ((position.toDouble() / duration.toDouble()) * 1000).toInt()

        // Adresse + QR code : régénérés uniquement si l'adresse a changé (évite de recréer
        // le bitmap à chaque tick et gère automatiquement un changement d'IP en direct).
        val ip = if (running) RadioState.localIp else (NetworkUtils.getLocalIpAddress(this) ?: "")
        val port = if (running) RadioState.port else (etPort.text.toString().toIntOrNull() ?: 8080)
        val address = if (ip.isNotEmpty()) "http://$ip:$port" else "En attente du Wi-Fi…"

        if (address != lastRenderedAddress) {
            lastRenderedAddress = address
            tvAddress.text = address
            if (ip.isNotEmpty()) {
                val bitmap = QrCodeGenerator.generate(address)
                imgQrCode.setImageBitmap(bitmap)
            }
        }
    }
}
