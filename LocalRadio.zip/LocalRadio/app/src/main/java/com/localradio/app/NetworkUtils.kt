package com.localradio.app

import android.content.Context
import android.net.wifi.WifiManager
import android.text.format.Formatter
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

object NetworkUtils {

    /**
     * Retourne l'adresse IPv4 locale du téléphone sur le réseau Wi-Fi actuel,
     * ou null si aucune adresse valide n'est trouvée (pas de Wi-Fi).
     */
    fun getLocalIpAddress(context: Context): String? {
        // 1. Tentative via WifiManager (le plus fiable quand connecté en Wi-Fi)
        try {
            val wifiManager = context.applicationContext
                .getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val ipInt = wifiManager?.connectionInfo?.ipAddress ?: 0
            if (ipInt != 0) {
                val ip = Formatter.formatIpAddress(ipInt)
                if (ip != "0.0.0.0") return ip
            }
        } catch (e: Exception) {
            // on retombe sur la méthode générique ci-dessous
        }

        // 2. Parcours des interfaces réseau (fonctionne aussi pour hotspot / Ethernet)
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (iface in interfaces) {
                if (!iface.isUp || iface.isLoopback) continue
                val addresses = Collections.list(iface.inetAddresses)
                for (addr in addresses) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        val ip = addr.hostAddress ?: continue
                        if (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172.")) {
                            return ip
                        }
                    }
                }
            }
            // 3. Repli : toute adresse IPv4 non-loopback trouvée
            for (iface in interfaces) {
                if (!iface.isUp || iface.isLoopback) continue
                val addresses = Collections.list(iface.inetAddresses)
                for (addr in addresses) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        return addr.hostAddress
                    }
                }
            }
        } catch (e: Exception) {
            // ignoré
        }
        return null
    }
}
