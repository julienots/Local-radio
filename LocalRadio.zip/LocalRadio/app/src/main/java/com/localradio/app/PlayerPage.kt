package com.localradio.app

/** Génère la page HTML servie aux auditeurs sur "/". */
object PlayerPage {

    fun html(): String = """
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>LocalRadio — En direct</title>
<style>
  :root {
    --bg: #0E0F13;
    --surface: #1A1C22;
    --accent: #00E5A0;
    --text: #F5F6FA;
    --text-secondary: #9AA0AC;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    min-height: 100vh;
    background: var(--bg);
    color: var(--text);
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px;
  }
  .card {
    background: var(--surface);
    border-radius: 24px;
    padding: 32px 28px;
    max-width: 420px;
    width: 100%;
    box-shadow: 0 20px 60px rgba(0,0,0,0.4);
    text-align: center;
  }
  .live-dot {
    display: inline-block;
    width: 10px; height: 10px;
    background: var(--accent);
    border-radius: 50%;
    margin-right: 8px;
    animation: pulse 1.4s infinite;
  }
  @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.3; } 100% { opacity: 1; } }
  .station-name { font-size: 26px; font-weight: 700; margin: 6px 0 2px; }
  .live-label { color: var(--text-secondary); font-size: 13px; font-weight: 600; letter-spacing: 1px; text-transform: uppercase; }
  .track-name { margin-top: 22px; font-size: 18px; font-weight: 600; min-height: 26px; word-break: break-word; }
  .progress-wrap { margin-top: 16px; }
  .progress-bar { width: 100%; height: 6px; background: #2E3038; border-radius: 4px; overflow: hidden; }
  .progress-fill { height: 100%; background: var(--accent); width: 0%; transition: width 0.5s linear; }
  .time-row { display:flex; justify-content: space-between; font-size: 11px; color: var(--text-secondary); margin-top: 6px; }
  .controls { margin-top: 26px; display: flex; align-items: center; justify-content: center; gap: 20px; }
  .play-btn {
    width: 64px; height: 64px; border-radius: 50%;
    background: var(--accent); border: none; cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    font-size: 22px; color: var(--bg);
  }
  .volume-row { margin-top: 24px; display: flex; align-items: center; gap: 10px; }
  input[type=range] { flex: 1; accent-color: var(--accent); }
  .listeners { margin-top: 20px; font-size: 12px; color: var(--text-secondary); }
</style>
</head>
<body>
  <div class="card">
    <div><span class="live-dot"></span><span class="live-label" id="liveLabel">EN DIRECT</span></div>
    <div class="station-name" id="stationName">LocalRadio</div>
    <div class="track-name" id="trackName">Connexion à la radio…</div>

    <div class="progress-wrap">
      <div class="progress-bar"><div class="progress-fill" id="progressFill"></div></div>
      <div class="time-row"><span id="timeCurrent">0:00</span><span id="timeTotal">0:00</span></div>
    </div>

    <div class="controls">
      <button class="play-btn" id="playBtn" onclick="togglePlay()">▶</button>
    </div>

    <div class="volume-row">
      <span>🔉</span>
      <input type="range" id="volumeSlider" min="0" max="100" value="80" oninput="setVolume(this.value)">
      <span>🔊</span>
    </div>

    <div class="listeners" id="listenersLabel"></div>
  </div>

  <audio id="player" preload="none">
    <source src="/stream">
  </audio>

<script>
  const audio = document.getElementById('player');
  const playBtn = document.getElementById('playBtn');
  let isPlaying = false;

  function togglePlay() {
    if (isPlaying) {
      audio.pause();
      playBtn.textContent = '▶';
      isPlaying = false;
    } else {
      audio.src = '/stream?t=' + Date.now(); // rejoint le direct au point courant
      audio.play().catch(() => {});
      playBtn.textContent = '❚❚';
      isPlaying = true;
    }
  }

  function setVolume(val) {
    audio.volume = val / 100;
  }
  audio.volume = 0.8;

  function formatTime(ms) {
    const totalSec = Math.floor(ms / 1000);
    const min = Math.floor(totalSec / 60);
    const sec = totalSec % 60;
    return min + ':' + (sec < 10 ? '0' : '') + sec;
  }

  async function refreshStatus() {
    try {
      const res = await fetch('/status', { cache: 'no-store' });
      const data = await res.json();
      document.getElementById('stationName').textContent = data.station || 'LocalRadio';
      document.getElementById('trackName').textContent = data.track || '—';
      document.getElementById('liveLabel').textContent = data.playing ? 'EN DIRECT' : 'HORS LIGNE';
      document.getElementById('listenersLabel').textContent = data.listeners + ' auditeur(s) connecté(s)';

      const pct = data.duration > 0 ? Math.min(100, (data.position / data.duration) * 100) : 0;
      document.getElementById('progressFill').style.width = pct + '%';
      document.getElementById('timeCurrent').textContent = formatTime(data.position);
      document.getElementById('timeTotal').textContent = formatTime(data.duration);
    } catch (e) {
      document.getElementById('liveLabel').textContent = 'DÉCONNECTÉ';
    }
  }

  setInterval(refreshStatus, 1000);
  refreshStatus();
</script>
</body>
</html>
""".trimIndent()
}
