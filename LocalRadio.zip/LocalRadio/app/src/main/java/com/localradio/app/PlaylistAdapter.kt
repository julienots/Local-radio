package com.localradio.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PlaylistAdapter(
    private var tracks: List<Track>,
    private val onRemove: (Track) -> Unit
) : RecyclerView.Adapter<PlaylistAdapter.TrackViewHolder>() {

    var currentlyPlayingName: String? = null

    class TrackViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTrackName: TextView = view.findViewById(R.id.tvTrackName)
        val btnRemove: ImageButton = view.findViewById(R.id.btnRemoveTrack)
        val viewIndicator: View = view.findViewById(R.id.viewPlayingIndicator)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TrackViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_track, parent, false)
        return TrackViewHolder(view)
    }

    override fun onBindViewHolder(holder: TrackViewHolder, position: Int) {
        val track = tracks[position]
        holder.tvTrackName.text = track.displayName
        holder.viewIndicator.visibility =
            if (track.displayName == currentlyPlayingName) View.VISIBLE else View.INVISIBLE
        holder.btnRemove.setOnClickListener { onRemove(track) }
    }

    override fun getItemCount(): Int = tracks.size

    fun updateTracks(newTracks: List<Track>) {
        tracks = newTracks
        notifyDataSetChanged()
    }

    fun updateCurrentlyPlaying(name: String?) {
        currentlyPlayingName = name
        notifyDataSetChanged()
    }
}
