package com.localradio.app

import org.json.JSONObject

/**
 * Représente un morceau audio copié dans le stockage interne de l'application.
 * On copie systématiquement le fichier localement afin de garantir des lectures
 * répétées et fiables pendant la diffusion en direct, sans dépendre de permissions
 * de stockage persistantes sur l'Uri d'origine.
 */
data class Track(
    val id: String,
    val displayName: String,
    val filePath: String,
    val durationMs: Long,
    val mimeType: String
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("displayName", displayName)
        put("filePath", filePath)
        put("durationMs", durationMs)
        put("mimeType", mimeType)
    }

    companion object {
        fun fromJson(json: JSONObject): Track = Track(
            id = json.getString("id"),
            displayName = json.getString("displayName"),
            filePath = json.getString("filePath"),
            durationMs = json.optLong("durationMs", 0L),
            mimeType = json.optString("mimeType", "audio/mpeg")
        )
    }
}
