package com.localradio.app

import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Serveur HTTP minimal, écrit à la main avec java.net.ServerSocket, sans aucune
 * dépendance tierce. Il sert :
 *   - "/"        : la page web du lecteur (HTML/CSS/JS embarqués)
 *   - "/status"  : un JSON avec l'état courant (morceau, position, auditeurs...)
 *   - "/stream"  : le flux audio brut, poussé en direct à tous les auditeurs connectés
 *
 * Le flux audio est "live" : un seul thread de diffusion (RadioService) lit le
 * fichier en cours et pousse les mêmes octets, au même rythme, à tous les
 * clients connectés simultanément - comme une radio classique.
 */
class WebServer(private val port: Int) {

    private var serverSocket: ServerSocket? = null
    @Volatile private var running = false
    private var acceptThread: Thread? = null

    /** Connexions "/stream" actuellement ouvertes, chacune avec son propre socket. */
    private val streamClients = CopyOnWriteArrayList<StreamClient>()
    private val voiceClients = CopyOnWriteArrayList<StreamClient>()

    private inner class StreamClient(val socket: Socket, val output: OutputStream) {
        @Volatile var alive = true
        fun close() {
            alive = false
            try { socket.close() } catch (_: Exception) {}
        }
    }

    fun start() {
        if (running) return
        running = true
        serverSocket = ServerSocket(port)
        acceptThread = Thread {
            while (running) {
                try {
                    val socket = serverSocket!!.accept()
                    Thread { handleClient(socket) }.start()
                } catch (e: Exception) {
                    if (running) {
                        // socket fermé volontairement lors de stop() -> on ignore
                    }
                }
            }
        }.also { it.name = "LocalRadio-Accept"; it.start() }
    }

    fun stop() {
        running = false
        streamClients.forEach { it.close() }
        streamClients.clear()
        voiceClients.forEach { it.close() }
        voiceClients.clear()
        try { serverSocket?.close() } catch (_: Exception) {}
        serverSocket = null
    }

    fun listenerCount(): Int = streamClients.size

    /**
     * Appelé par le RadioService pour pousser un bloc d'octets audio à tous les
     * auditeurs connectés en même temps. Les clients dont l'écriture échoue
     * (déconnectés) sont retirés automatiquement.
     */
    fun broadcast(buffer: ByteArray, length: Int) {
        if (streamClients.isEmpty()) return
        for (client in streamClients) {
            try {
                client.output.write(buffer, 0, length)
                client.output.flush()
            } catch (e: IOException) {
                client.close()
                streamClients.remove(client)
                RadioState.listenerCount = streamClients.size
            }
        }
    }

    private fun handleClient(socket: Socket) {
        try {
            socket.soTimeout = 20000
            val input = BufferedReader(InputStreamReader(socket.getInputStream()))
            val requestLine = input.readLine() ?: run { socket.close(); return }
            // On consomme le reste des en-têtes HTTP sans les traiter (pas besoin ici).
            var line: String?
            do { line = input.readLine() } while (!line.isNullOrEmpty())

            val parts = requestLine.split(" ")
            if (parts.size < 2) { socket.close(); return }
            val path = parts[1].substringBefore("?")

            when (path) {
                "/", "/index.html" -> {
                    writeHttpResponse(socket.getOutputStream(), 200, "OK", "text/html; charset=utf-8", PlayerPage.html())
                    socket.close()
                }
                "/status" -> {
                    writeHttpResponse(socket.getOutputStream(), 200, "OK", "application/json", buildStatusJson())
                    socket.close()
                }
                "/stream" -> serveStream(socket)
                "/voice" -> serveVoice(socket)
                else -> {
                    writeHttpResponse(socket.getOutputStream(), 404, "Not Found", "text/plain", "404 Not Found")
                    socket.close()
                }
            }
        } catch (e: Exception) {
            try { socket.close() } catch (_: Exception) {}
        }
    }

    private fun serveStream(socket: Socket) {
        try {
            socket.soTimeout = 0 // pas de timeout : la connexion reste ouverte tant que le client écoute
            val output = socket.getOutputStream()
            val header = buildString {
                append("HTTP/1.1 200 OK\r\n")
                append("Content-Type: ${RadioState.currentMimeType}\r\n")
                append("Cache-Control: no-cache, no-store\r\n")
                append("Connection: close\r\n")
                append("Access-Control-Allow-Origin: *\r\n")
                append("Server: LocalRadio\r\n")
                append("\r\n")
            }
            output.write(header.toByteArray(Charsets.UTF_8))
            output.flush()

            val client = StreamClient(socket, output)
            streamClients.add(client)
            RadioState.listenerCount = streamClients.size

            // On lit le flux entrant pour détecter la déconnexion du client
            // (le navigateur ne renvoie rien, mais read() se débloquera avec -1
            // ou une exception lorsque la connexion est fermée côté client).
            val input = socket.getInputStream()
            val buf = ByteArray(256)
            while (client.alive) {
                val read = try { input.read(buf) } catch (e: SocketException) { -1 }
                if (read == -1) break
            }
        } catch (e: Exception) {
            // déconnexion normale
        } finally {
            streamClients.removeAll { it.socket == socket }
            RadioState.listenerCount = streamClients.size
            try { socket.close() } catch (_: Exception) {}
        }
    }


    /** Diffusion PCM 16 kHz mono utilisée pendant le direct micro. */
    private fun serveVoice(socket: Socket) {
        try {
            socket.soTimeout = 0
            val output = socket.getOutputStream()
            val header = buildString {
                append("HTTP/1.1 200 OK\r\n")
                append("Content-Type: audio/x-pcm;rate=16000;channels=1\r\n")
                append("Cache-Control: no-cache, no-store\r\n")
                append("Transfer-Encoding: chunked\r\n")
                append("Connection: close\r\n")
                append("Access-Control-Allow-Origin: *\r\n")
                append("Server: LocalRadio\r\n\r\n")
            }
            output.write(header.toByteArray(Charsets.UTF_8))
            output.flush()

            val client = StreamClient(socket, output)
            voiceClients.add(client)

            val input = socket.getInputStream()
            val buf = ByteArray(256)
            while (client.alive) {
                val read = try { input.read(buf) } catch (_: SocketException) { -1 }
                if (read == -1) break
            }
        } catch (_: Exception) {
        } finally {
            voiceClients.removeAll { it.socket == socket }
            try { socket.close() } catch (_: Exception) {}
        }
    }

    fun broadcastVoice(buffer: ByteArray, length: Int) {
        if (voiceClients.isEmpty()) return
        for (client in voiceClients) {
            try {
                // HTTP chunk framing lets fetch()/ReadableStream receive the PCM progressively.
                val size = Integer.toHexString(length).toByteArray(Charsets.US_ASCII)
                client.output.write(size)
                client.output.write("\r\n".toByteArray(Charsets.US_ASCII))
                client.output.write(buffer, 0, length)
                client.output.write("\r\n".toByteArray(Charsets.US_ASCII))
                client.output.flush()
            } catch (_: IOException) {
                client.close()
                voiceClients.remove(client)
            }
        }
    }

    private fun buildStatusJson(): String {
        return """
            {
              "station": "${escape(RadioState.stationName)}",
              "track": "${escape(RadioState.currentTrackName)}",
              "playing": ${RadioState.isRunning},
              "voice": ${RadioState.isVoiceLive},
              "listeners": ${RadioState.listenerCount},
              "position": ${RadioState.positionMs},
              "duration": ${RadioState.durationMs}
            }
        """.trimIndent()
    }

    private fun escape(s: String): String = s.replace("\\", "\\\\").replace("\"", "\\\"")

    private fun writeHttpResponse(
        output: OutputStream,
        code: Int,
        message: String,
        contentType: String,
        body: String
    ) {
        val bodyBytes = body.toByteArray(Charsets.UTF_8)
        val header = buildString {
            append("HTTP/1.1 $code $message\r\n")
            append("Content-Type: $contentType\r\n")
            append("Content-Length: ${bodyBytes.size}\r\n")
            append("Connection: close\r\n")
            append("Access-Control-Allow-Origin: *\r\n")
            append("\r\n")
        }
        output.write(header.toByteArray(Charsets.UTF_8))
        output.write(bodyBytes)
        output.flush()
    }
}
