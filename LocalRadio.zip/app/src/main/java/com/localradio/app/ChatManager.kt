package com.localradio.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.atomic.AtomicLong

/**
 * Stocke les messages du tchat en direct, en mémoire uniquement (pas de
 * persistance disque : le tchat repart de zéro à chaque redémarrage de la
 * radio, comme les commentaires en direct d'une vraie émission).
 *
 * Chaque message reçoit un identifiant croissant (nextId) : les clients web
 * font un simple "long polling léger" en interrogeant /chat/messages?since=X
 * toutes les 2 secondes pour ne récupérer que les nouveaux messages.
 */
object ChatManager {

    data class ChatMessage(val id: Long, val nickname: String, val text: String, val ts: Long)

    private const val MAX_HISTORY = 200
    private const val MAX_NICKNAME_LEN = 24
    private const val MAX_MESSAGE_LEN = 300

    private val messages = ConcurrentLinkedDeque<ChatMessage>()
    private val idCounter = AtomicLong(0)

    fun reset() {
        messages.clear()
        idCounter.set(0)
    }

    /** Ajoute un message si le pseudo et le texte ne sont pas vides ; renvoie false sinon. */
    fun add(nickname: String, text: String): Boolean {
        val cleanNick = nickname.trim().take(MAX_NICKNAME_LEN).ifEmpty { "Auditeur" }
        val cleanText = text.trim().take(MAX_MESSAGE_LEN)
        if (cleanText.isEmpty()) return false

        val msg = ChatMessage(idCounter.incrementAndGet(), cleanNick, cleanText, System.currentTimeMillis())
        messages.addLast(msg)
        while (messages.size > MAX_HISTORY) messages.pollFirst()
        return true
    }

    /** Renvoie les messages dont l'id est strictement supérieur à `since`. */
    fun since(since: Long): List<ChatMessage> = messages.filter { it.id > since }

    fun toJsonArray(list: List<ChatMessage>): String {
        val arr = JSONArray()
        list.forEach { m ->
            arr.put(
                JSONObject().apply {
                    put("id", m.id)
                    put("nick", m.nickname)
                    put("text", m.text)
                    put("ts", m.ts)
                }
            )
        }
        return arr.toString()
    }
}
