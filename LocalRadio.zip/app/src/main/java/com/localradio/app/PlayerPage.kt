package com.localradio.app

/** Génère la page HTML servie aux auditeurs sur "/". */
object PlayerPage {

    fun html(): String = """
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>LocalRadio — En direct</title>
<style>
  :root {
    --bg: #0E0F13;
    --surface: #1A1C22;
    --accent: #00E5A0;
    --text: #F5F6FA;
    --text-secondary: #9AA0AC;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    min-height: 100vh;
    background: var(--bg);
    color: var(--text);
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px;
  }
  .card {
    background: var(--surface);
    border-radius: 24px;
    padding: 32px 28px;
    max-width: 420px;
    width: 100%;
    box-shadow: 0 20px 60px rgba(0,0,0,0.4);
    text-align: center;
  }
  .live-dot {
    display: inline-block;
    width: 10px; height: 10px;
    background: var(--accent);
    border-radius: 50%;
    margin-right: 8px;
    animation: pulse 1.4s infinite;
  }
  @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.3; } 100% { opacity: 1; } }
  .station-name { font-size: 26px; font-weight: 700; margin: 6px 0 2px; }
  .live-label { color: var(--text-secondary); font-size: 13px; font-weight: 600; letter-spacing: 1px; text-transform: uppercase; }
  .track-name { margin-top: 22px; font-size: 18px; font-weight: 600; min-height: 26px; word-break: break-word; }
  .progress-wrap { margin-top: 16px; }
  .progress-bar { width: 100%; height: 6px; background: #2E3038; border-radius: 4px; overflow: hidden; }
  .progress-fill { height: 100%; background: var(--accent); width: 0%; transition: width 0.5s linear; }
  .time-row { display:flex; justify-content: space-between; font-size: 11px; color: var(--text-secondary); margin-top: 6px; }
  .controls { margin-top: 26px; display: flex; align-items: center; justify-content: center; gap: 20px; }
  .play-btn {
    width: 64px; height: 64px; border-radius: 50%;
    background: var(--accent); border: none; cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    font-size: 22px; color: var(--bg);
  }
  .volume-row { margin-top: 24px; display: flex; align-items: center; gap: 10px; }
  input[type=range] { flex: 1; accent-color: var(--accent); }
  .listeners { margin-top: 20px; font-size: 12px; color: var(--text-secondary); }

  .chat-box {
    margin-top: 24px;
    text-align: left;
    border-top: 1px solid #2E3038;
    padding-top: 16px;
  }
  .chat-title { font-size: 12px; font-weight: 700; letter-spacing: 0.5px; text-transform: uppercase; color: var(--text-secondary); margin-bottom: 8px; }
  .chat-messages {
    max-height: 220px;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
    gap: 6px;
    padding-right: 4px;
  }
  .chat-msg { font-size: 13px; line-height: 1.35; word-break: break-word; }
  .chat-msg .nick { color: var(--accent); font-weight: 700; margin-right: 4px; }
  .chat-empty { color: var(--text-secondary); font-size: 12px; font-style: italic; }
  .chat-form { display: flex; gap: 8px; margin-top: 12px; }
  .chat-form input[type=text] {
    flex: 1;
    background: #22242C;
    border: 1px solid #2E3038;
    border-radius: 10px;
    padding: 10px 12px;
    color: var(--text);
    font-size: 13px;
    outline: none;
  }
  .chat-form input#chatNick { flex: 0 0 84px; }
  .chat-send-btn {
    background: var(--accent);
    border: none;
    border-radius: 10px;
    padding: 0 16px;
    font-weight: 700;
    color: var(--bg);
    cursor: pointer;
  }
</style>
</head>
<body>
  <div class="card">
    <div><span class="live-dot"></span><span class="live-label" id="liveLabel">EN DIRECT</span></div>
    <div class="station-name" id="stationName">LocalRadio</div>
    <div class="track-name" id="trackName">Connexion à la radio…</div>

    <div class="progress-wrap">
      <div class="progress-bar"><div class="progress-fill" id="progressFill"></div></div>
      <div class="time-row"><span id="timeCurrent">0:00</span><span id="timeTotal">0:00</span></div>
    </div>

    <div class="controls">
      <button class="play-btn" id="playBtn" onclick="togglePlay()">▶</button>
    </div>

    <div class="volume-row">
      <span>🔉</span>
      <input type="range" id="volumeSlider" min="0" max="100" value="80" oninput="setVolume(this.value)">
      <span>🔊</span>
    </div>

    <div class="listeners" id="listenersLabel"></div>

    <div class="chat-box">
      <div class="chat-title">💬 Discussion en direct</div>
      <div class="chat-messages" id="chatMessages">
        <div class="chat-empty" id="chatEmpty">Aucun message pour l'instant. Soyez le premier à écrire !</div>
      </div>
      <div class="chat-form">
        <input type="text" id="chatNick" maxlength="24" placeholder="Pseudo">
        <input type="text" id="chatText" maxlength="300" placeholder="Écrire un message…" onkeydown="if(event.key==='Enter') sendChat();">
        <button class="chat-send-btn" onclick="sendChat()">Envoyer</button>
      </div>
    </div>
  </div>

  <audio id="player" preload="none">
    <source src="/stream">
  </audio>

<script>
  const audio = document.getElementById('player');
  const playBtn = document.getElementById('playBtn');
  let isPlaying = false;
  let voiceMode = false;
  let voiceAbort = null;
  let voiceContext = null;
  let nextVoiceTime = 0;
  let userStarted = false;
  let musicVolume = 0.8; // volume "normal" choisi par l'auditeur (curseur)
  const DUCK_RATIO = 0.18; // fraction du volume normal gardée en fond pendant le direct micro

  function applyMusicVolume() {
    audio.volume = voiceMode ? musicVolume * DUCK_RATIO : musicVolume;
  }

  function stopVoicePlayback() {
    if (voiceAbort) { try { voiceAbort.abort(); } catch(e) {} voiceAbort = null; }
    voiceMode = false;
    nextVoiceTime = 0;
    applyMusicVolume(); // remet la musique à son volume normal
  }

  async function startVoicePlayback() {
    if (voiceMode) return;
    try {
      // On ne met plus la musique en pause : elle continue de tourner, juste plus
      // discrète (fond sonore) pendant que la voix passe par-dessus via /voice.
      voiceMode = true;
      applyMusicVolume();
      if (!voiceContext) voiceContext = new (window.AudioContext || window.webkitAudioContext)();
      await voiceContext.resume();
      const controller = new AbortController();
      voiceAbort = controller;
      const res = await fetch('/voice?t=' + Date.now(), { cache: 'no-store', signal: controller.signal });
      if (!res.body) throw new Error('Streaming non supporté');
      const reader = res.body.getReader();
      let carry = new Uint8Array(0);
      nextVoiceTime = voiceContext.currentTime + 0.08;
      while (voiceMode) {
        const result = await reader.read();
        if (result.done) break;
        let bytes = result.value;
        if (carry.length) {
          const merged = new Uint8Array(carry.length + bytes.length);
          merged.set(carry); merged.set(bytes, carry.length); bytes = merged;
          carry = new Uint8Array(0);
        }
        if (bytes.byteLength % 2) {
          carry = bytes.slice(bytes.byteLength - 1);
          bytes = bytes.slice(0, bytes.byteLength - 1);
        }
        if (!bytes.byteLength) continue;
        const sampleCount = bytes.byteLength / 2;
        const samples = new Int16Array(bytes.buffer, bytes.byteOffset, sampleCount);
        const buffer = voiceContext.createBuffer(1, samples.length, 16000);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < samples.length; i++) data[i] = samples[i] / 32768;
        const source = voiceContext.createBufferSource();
        source.buffer = buffer;
        source.connect(voiceContext.destination);
        const startAt = Math.max(nextVoiceTime, voiceContext.currentTime + 0.02);
        source.start(startAt);
        nextVoiceTime = startAt + buffer.duration;
      }
    } catch (e) {
      if (e.name !== 'AbortError') console.log(e);
    }
  }

  function togglePlay() {
    if (isPlaying) {
      audio.pause();
      playBtn.textContent = '▶';
      isPlaying = false;
    } else {
      userStarted = true;
      if (!voiceContext) voiceContext = new (window.AudioContext || window.webkitAudioContext)();
      voiceContext.resume().catch(() => {});
      // Si un direct micro est déjà en cours, on ne le coupe plus : on relance juste
      // la musique en fond à son volume réduit, et le direct continue par-dessus.
      audio.src = '/stream?t=' + Date.now();
      applyMusicVolume();
      audio.play().catch(() => {});
      playBtn.textContent = '❚❚';
      isPlaying = true;
    }
  }

  function setVolume(val) {
    musicVolume = val / 100;
    applyMusicVolume();
  }
  applyMusicVolume();

  function formatTime(ms) {
    const totalSec = Math.floor(ms / 1000);
    const min = Math.floor(totalSec / 60);
    const sec = totalSec % 60;
    return min + ':' + (sec < 10 ? '0' : '') + sec;
  }

  async function refreshStatus() {
    try {
      const res = await fetch('/status', { cache: 'no-store' });
      const data = await res.json();
      document.getElementById('stationName').textContent = data.station || 'LocalRadio';
      document.getElementById('trackName').textContent = data.track || '—';
      document.getElementById('liveLabel').textContent = data.playing ? 'EN DIRECT' : 'HORS LIGNE';
      if (data.voice && userStarted && !voiceMode) startVoicePlayback();
      // La musique n'est jamais mise en pause pendant le direct (juste baissée) : on ne
      // touche donc plus à isPlaying/playBtn ici, elle continue de jouer normalement.
      if (!data.voice && voiceMode) stopVoicePlayback();
      document.getElementById('listenersLabel').textContent = data.listeners + ' auditeur(s) connecté(s)';

      const pct = data.duration > 0 ? Math.min(100, (data.position / data.duration) * 100) : 0;
      document.getElementById('progressFill').style.width = pct + '%';
      document.getElementById('timeCurrent').textContent = formatTime(data.position);
      document.getElementById('timeTotal').textContent = formatTime(data.duration);
    } catch (e) {
      document.getElementById('liveLabel').textContent = 'DÉCONNECTÉ';
    }
  }

  setInterval(refreshStatus, 1000);
  refreshStatus();

  // --- Discussion en direct ---------------------------------------------
  const chatMessagesEl = document.getElementById('chatMessages');
  const chatEmptyEl = document.getElementById('chatEmpty');
  const chatNickEl = document.getElementById('chatNick');
  const chatTextEl = document.getElementById('chatText');
  let lastChatId = 0;
  let chatAutoScroll = true;

  // Le pseudo est mémorisé sur cet appareil pour ne pas avoir à le retaper.
  try {
    const savedNick = localStorage.getItem('localradio_nick');
    if (savedNick) chatNickEl.value = savedNick;
  } catch (e) {}

  function escapeHtml(s) {
    return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function appendChatMessages(list) {
    if (!list.length) return;
    if (chatEmptyEl) { chatEmptyEl.remove(); }
    list.forEach(m => {
      const div = document.createElement('div');
      div.className = 'chat-msg';
      div.innerHTML = '<span class="nick">' + escapeHtml(m.nick) + '</span>' + escapeHtml(m.text);
      chatMessagesEl.appendChild(div);
      lastChatId = Math.max(lastChatId, m.id);
    });
    // On ne fait défiler automatiquement que si l'utilisateur était déjà en bas
    // (pour ne pas le déranger s'il relit d'anciens messages).
    if (chatAutoScroll) chatMessagesEl.scrollTop = chatMessagesEl.scrollHeight;
  }

  chatMessagesEl.addEventListener('scroll', () => {
    const gap = chatMessagesEl.scrollHeight - chatMessagesEl.scrollTop - chatMessagesEl.clientHeight;
    chatAutoScroll = gap < 40;
  });

  async function pollChat() {
    try {
      const res = await fetch('/chat/messages?since=' + lastChatId, { cache: 'no-store' });
      const list = await res.json();
      appendChatMessages(list);
    } catch (e) {}
  }

  async function sendChat() {
    const nick = chatNickEl.value.trim() || 'Auditeur';
    const text = chatTextEl.value.trim();
    if (!text) return;
    try { localStorage.setItem('localradio_nick', nick); } catch (e) {}
    chatTextEl.value = '';
    try {
      await fetch('/chat/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'nick=' + encodeURIComponent(nick) + '&text=' + encodeURIComponent(text)
      });
      chatAutoScroll = true;
      pollChat();
    } catch (e) {}
  }

  setInterval(pollChat, 2000);
  pollChat();
</script>
</body>
</html>
""".trimIndent()
}
