package com.localradio.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PlaylistAdapter(
    private var tracks: List<Track>,
    private val onRemove: (Track) -> Unit,
    private val onLongPress: (Track) -> Unit = {}
) : RecyclerView.Adapter<PlaylistAdapter.TrackViewHolder>() {

    var currentlyPlayingName: String? = null
    var introRadioTrackId: String? = null
    var introVoiceTrackId: String? = null
    var outroVoiceTrackId: String? = null

    class TrackViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTrackName: TextView = view.findViewById(R.id.tvTrackName)
        val btnRemove: ImageButton = view.findViewById(R.id.btnRemoveTrack)
        val viewIndicator: View = view.findViewById(R.id.viewPlayingIndicator)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TrackViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_track, parent, false)
        return TrackViewHolder(view)
    }

    override fun onBindViewHolder(holder: TrackViewHolder, position: Int) {
        val track = tracks[position]
        val badge = buildString {
            if (track.id == introRadioTrackId) append("🔔 ")
            if (track.id == introVoiceTrackId) append("🎙️🔔 ")
            if (track.id == outroVoiceTrackId) append("🎙️🔚 ")
        }
        holder.tvTrackName.text = badge + track.displayName
        holder.viewIndicator.visibility =
            if (track.displayName == currentlyPlayingName) View.VISIBLE else View.INVISIBLE
        holder.btnRemove.setOnClickListener { onRemove(track) }
        holder.itemView.setOnLongClickListener { onLongPress(track); true }
    }

    override fun getItemCount(): Int = tracks.size

    fun updateTracks(newTracks: List<Track>) {
        tracks = newTracks
        notifyDataSetChanged()
    }

    fun updateCurrentlyPlaying(name: String?) {
        currentlyPlayingName = name
        notifyDataSetChanged()
    }

    fun updateIntros(introRadioId: String?, introVoiceId: String?, outroVoiceId: String? = null) {
        introRadioTrackId = introRadioId
        introVoiceTrackId = introVoiceId
        outroVoiceTrackId = outroVoiceId
        notifyDataSetChanged()
    }
}
