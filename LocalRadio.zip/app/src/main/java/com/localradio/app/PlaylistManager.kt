package com.localradio.app

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import java.io.File
import java.util.UUID

/**
 * Source de vérité unique pour la playlist, partagée entre l'UI (MainActivity)
 * et le service de diffusion (RadioService). Les fichiers sélectionnés par
 * l'utilisateur sont copiés dans le stockage interne de l'app (files/tracks)
 * pour permettre des lectures répétées et fiables pendant le direct.
 */
object PlaylistManager {

    private const val PREFS = "localradio_prefs"
    private const val KEY_PLAYLIST = "playlist_json"
    private const val KEY_PORT = "port"
    private const val KEY_PUBLIC_URL = "public_url"
    private const val KEY_INTRO_RADIO = "intro_radio_track_id"
    private const val KEY_INTRO_VOICE = "intro_voice_track_id"
    private const val KEY_OUTRO_VOICE = "outro_voice_track_id"

    fun load(context: Context): List<Track> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_PLAYLIST, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val list = mutableListOf<Track>()
            for (i in 0 until arr.length()) {
                val track = Track.fromJson(arr.getJSONObject(i))
                if (File(track.filePath).exists()) list.add(track)
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun save(context: Context, tracks: List<Track>) {
        val arr = JSONArray()
        tracks.forEach { arr.put(it.toJson()) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PLAYLIST, arr.toString())
            .apply()
    }

    fun getPort(context: Context): Int {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(KEY_PORT, 8080)
    }

    fun setPort(context: Context, port: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_PORT, port)
            .apply()
    }

    /**
     * Adresse publique (obtenue via un tunnel externe comme ngrok, voir le README)
     * saisie manuellement par l'utilisateur pour diffuser au-delà du Wi-Fi local.
     */
    fun getPublicUrl(context: Context): String {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_PUBLIC_URL, "") ?: ""
    }

    fun setPublicUrl(context: Context, url: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PUBLIC_URL, url)
            .apply()
    }

    /**
     * Intro jouée une seule fois juste après avoir appuyé sur "Démarrer la radio",
     * avant que la playlist ne commence à tourner en boucle (jingle d'ouverture,
     * indicatif de la station, etc.). null = pas d'intro configurée.
     */
    fun getIntroRadioTrackId(context: Context): String? {
        val v = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_INTRO_RADIO, null)
        return if (v.isNullOrEmpty()) null else v
    }

    fun setIntroRadioTrackId(context: Context, trackId: String?) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_INTRO_RADIO, trackId)
            .apply()
    }

    /**
     * Intro jouée une seule fois juste avant de basculer sur le micro en direct
     * (jingle "vous êtes en direct", etc.). null = pas d'intro configurée.
     */
    fun getIntroVoiceTrackId(context: Context): String? {
        val v = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_INTRO_VOICE, null)
        return if (v.isNullOrEmpty()) null else v
    }

    fun setIntroVoiceTrackId(context: Context, trackId: String?) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_INTRO_VOICE, trackId)
            .apply()
    }

    /**
     * Son de coupure joué une seule fois juste après avoir arrêté le micro en direct,
     * avant que la musique ne reprenne normalement (jingle "c'était en direct", etc.).
     * null = pas de son de coupure configuré.
     */
    fun getOutroVoiceTrackId(context: Context): String? {
        val v = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_OUTRO_VOICE, null)
        return if (v.isNullOrEmpty()) null else v
    }

    fun setOutroVoiceTrackId(context: Context, trackId: String?) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_OUTRO_VOICE, trackId)
            .apply()
    }

    /** Copie un fichier audio sélectionné par l'utilisateur dans le stockage interne. */
    fun addTrackFromUri(context: Context, uri: Uri): Track? {
        return try {
            val id = UUID.randomUUID().toString()
            val displayName = queryDisplayName(context, uri) ?: "Morceau"
            val extension = displayName.substringAfterLast('.', "mp3")
            val destDir = File(context.filesDir, "tracks").apply { mkdirs() }
            val destFile = File(destDir, "$id.$extension")

            context.contentResolver.openInputStream(uri)?.use { input ->
                destFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: return null

            val durationMs = extractDuration(destFile)
            val mimeType = context.contentResolver.getType(uri)
                ?: mimeFromExtension(extension)

            val track = Track(
                id = id,
                displayName = displayName,
                filePath = destFile.absolutePath,
                durationMs = durationMs,
                mimeType = mimeType
            )

            val current = load(context).toMutableList()
            current.add(track)
            save(context, current)
            track
        } catch (e: Exception) {
            null
        }
    }

    fun removeTrack(context: Context, trackId: String) {
        val current = load(context).toMutableList()
        val toRemove = current.find { it.id == trackId }
        toRemove?.let {
            File(it.filePath).delete()
            current.remove(it)
            save(context, current)
            if (getIntroRadioTrackId(context) == trackId) setIntroRadioTrackId(context, null)
            if (getIntroVoiceTrackId(context) == trackId) setIntroVoiceTrackId(context, null)
            if (getOutroVoiceTrackId(context) == trackId) setOutroVoiceTrackId(context, null)
        }
    }

    private fun queryDisplayName(context: Context, uri: Uri): String? {
        var name: String? = null
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIndex >= 0) {
                name = cursor.getString(nameIndex)
            }
        }
        return name
    }

    private fun extractDuration(file: File): Long {
        return try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(file.absolutePath)
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            retriever.release()
            duration?.toLongOrNull() ?: estimateDurationFromSize(file)
        } catch (e: Exception) {
            estimateDurationFromSize(file)
        }
    }

    /** Estimation de secours basée sur un débit moyen de 128 kbps si les métadonnées échouent. */
    private fun estimateDurationFromSize(file: File): Long {
        val bytesPerMs = 16000.0 / 1000.0 // 128 kbps ≈ 16 000 octets/s
        return (file.length() / bytesPerMs).toLong().coerceAtLeast(1000L)
    }

    private fun mimeFromExtension(extension: String): String = when (extension.lowercase()) {
        "mp3" -> "audio/mpeg"
        "wav" -> "audio/wav"
        "ogg" -> "audio/ogg"
        "m4a", "aac" -> "audio/mp4"
        "flac" -> "audio/flac"
        else -> "audio/mpeg"
    }
}
