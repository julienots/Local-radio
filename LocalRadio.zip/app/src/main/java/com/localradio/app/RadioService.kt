package com.localradio.app

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import java.io.File
import java.io.FileInputStream

class RadioService : Service() {

    private var webServer: WebServer? = null
    private var broadcastThread: Thread? = null
    @Volatile private var shouldRun = false

    private var localPlayer: MediaPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var voiceThread: Thread? = null
    private var audioRecord: AudioRecord? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val port = intent.getIntExtra(EXTRA_PORT, 8080)
                startRadio(port)
            }
            ACTION_STOP -> stopRadio()
            ACTION_START_VOICE -> startVoice()
            ACTION_STOP_VOICE -> stopVoice()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopRadio()
        super.onDestroy()
    }

    private fun startRadio(port: Int) {
        if (shouldRun) return
        shouldRun = true

        RadioState.port = port
        RadioState.localIp = NetworkUtils.getLocalIpAddress(this) ?: ""
        RadioState.isRunning = true
        RadioState.listenerCount = 0
        RadioState.isVoiceLive = false
        RadioState.isIntroPlaying = false
        ChatManager.reset()

        // On n'active QUE le type "lecture média" au démarrage : le type "microphone" est
        // activé séparément dans startVoice(), uniquement quand le micro est réellement
        // utilisé (et donc que la permission RECORD_AUDIO est garantie accordée). Déclarer
        // le type microphone trop tôt peut provoquer un SecurityException sur Android 14+
        // si la permission n'a pas encore été accordée à ce moment-là.
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    buildNotification("Diffusion en cours…"),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                )
            } else {
                startForeground(NOTIFICATION_ID, buildNotification("Diffusion en cours…"))
            }
        } catch (e: Exception) {
            startForeground(NOTIFICATION_ID, buildNotification("Diffusion en cours…"))
        }

        acquireLocks()

        webServer = WebServer(port).also { it.start() }

        localPlayer = MediaPlayer()

        broadcastThread = Thread { broadcastLoop() }.also {
            it.name = "LocalRadio-Broadcast"
            it.start()
        }
    }

    private fun stopRadio() {
        shouldRun = false
        RadioState.reset()

        broadcastThread?.interrupt()
        broadcastThread = null

        webServer?.stop()
        webServer = null

        try { localPlayer?.stop() } catch (_: Exception) {}
        try { localPlayer?.release() } catch (_: Exception) {}
        localPlayer = null

        stopVoice()
        releaseLocks()

        @Suppress("DEPRECATION")
        stopForeground(true)
        stopSelf()
    }

    /**
     * Boucle principale de diffusion : parcourt la playlist en continu, lit chaque
     * fichier par blocs et pousse les mêmes octets, au même rythme, à tous les
     * auditeurs connectés (simule une vraie radio en direct et synchronisée).
     */
    private fun broadcastLoop() {
        var index = 0

        // Intro configurée pour le démarrage de la radio (voir MainActivity / réglages
        // "intro" sur un morceau) : jouée une seule fois avant d'entrer dans la boucle
        // normale de la playlist.
        val introTrackId = PlaylistManager.getIntroRadioTrackId(this)
        val introTrack = introTrackId?.let { id -> PlaylistManager.load(this).find { it.id == id } }
        if (introTrack != null && shouldRun) {
            RadioState.isIntroPlaying = true
            playTrackAndBroadcast(introTrack, allowInterruptByIntro = false)
            RadioState.isIntroPlaying = false
        }

        while (shouldRun) {
            val playlist = PlaylistManager.load(this)
            // On ne met la boucle en pause que pour un jingle (intro/coupure) en cours,
            // joué par un thread dédié en dehors de cette boucle. Le direct micro NE
            // coupe PLUS la musique : elle continue de tourner en fond (volume baissé,
            // voir beginVoiceCapture/stopVoice) pendant que la voix passe sur /voice.
            if (RadioState.isIntroPlaying) {
                sleepQuiet(100)
                continue
            }
            if (playlist.isEmpty()) {
                RadioState.currentTrackName = "Aucun morceau dans la playlist"
                RadioState.durationMs = 0
                RadioState.positionMs = 0
                sleepQuiet(1500)
                continue
            }
            val track = playlist[index % playlist.size]
            index++
            playTrackAndBroadcast(track)
        }
    }

    private fun playTrackAndBroadcast(track: Track, allowInterruptByIntro: Boolean = true) {
        val file = File(track.filePath)
        if (!file.exists()) return

        RadioState.currentTrackName = if (RadioState.isIntroPlaying) "🔔 ${track.displayName}" else track.displayName
        RadioState.currentMimeType = track.mimeType
        RadioState.durationMs = if (track.durationMs > 0) track.durationMs else 1L
        RadioState.positionMs = 0
        updateNotification("En direct : ${track.displayName}")

        // Lecture locale pour l'auditeur qui tient le téléphone hôte.
        try {
            localPlayer?.reset()
            localPlayer?.setDataSource(file.absolutePath)
            localPlayer?.prepare()
            localPlayer?.start()
        } catch (e: Exception) {
            // la diffusion réseau continue même si la lecture locale échoue
        }

        val totalBytes = file.length().coerceAtLeast(1)
        val bytesPerMs = totalBytes.toDouble() / RadioState.durationMs.toDouble()
        val bufferSize = 4096
        val buffer = ByteArray(bufferSize)

        try {
            FileInputStream(file).use { fis ->
                val startTime = System.currentTimeMillis()
                var sentBytes = 0L
                // Le direct micro (RadioState.isVoiceLive) n'interrompt plus la diffusion :
                // la musique continue de tourner en fond, en volume réduit (ducking), pendant
                // que la voix est mixée séparément sur /voice. Seul un jingle (intro/coupure,
                // allowInterruptByIntro) coupe encore la piste en cours.
                while (shouldRun && !(allowInterruptByIntro && RadioState.isIntroPlaying)) {
                    val read = fis.read(buffer)
                    if (read == -1) break

                    webServer?.broadcast(buffer, read)
                    sentBytes += read

                    // Cadence la diffusion sur la durée réelle du morceau (débit constant estimé)
                    val expectedElapsed = (sentBytes / bytesPerMs).toLong()
                    val actualElapsed = System.currentTimeMillis() - startTime
                    val delta = expectedElapsed - actualElapsed
                    if (delta > 0) sleepQuiet(delta)

                    RadioState.positionMs = System.currentTimeMillis() - startTime
                }
            }
        } catch (e: Exception) {
            // fichier illisible ou diffusion interrompue -> on passe au morceau suivant
        }

        try { localPlayer?.stop() } catch (_: Exception) {}
    }

    private fun startVoice() {
        if (!shouldRun || RadioState.isVoiceLive) return
        if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            toast("Autorisation micro requise")
            return
        }

        // Intro configurée pour le passage en direct micro (voir MainActivity) : jouée
        // une seule fois, diffusée sur le flux normal (/stream) pendant que la boucle de
        // playlist est mise en pause, puis on bascule réellement sur le micro ensuite.
        val introTrackId = PlaylistManager.getIntroVoiceTrackId(this)
        val introTrack = introTrackId?.let { id -> PlaylistManager.load(this).find { it.id == id } }
        if (introTrack != null) {
            Thread {
                RadioState.isIntroPlaying = true
                playTrackAndBroadcast(introTrack, allowInterruptByIntro = false)
                RadioState.isIntroPlaying = false
                beginVoiceCapture()
            }.also { it.name = "LocalRadio-VoiceIntro"; it.start() }
        } else {
            beginVoiceCapture()
        }
    }

    private fun beginVoiceCapture() {
        if (!shouldRun || RadioState.isVoiceLive) return

        // getMinBufferSize peut renvoyer ERROR/ERROR_BAD_VALUE (négatif) si la config
        // 16kHz mono PCM16 n'est pas supportée par le matériel : on abandonne proprement
        // plutôt que de construire un AudioRecord avec une taille de buffer invalide.
        val minBuffer = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuffer <= 0) {
            toast("Micro indisponible sur cet appareil")
            return
        }
        val bufferSize = minBuffer * 2

        // Le constructeur AudioRecord peut lever une exception (permission révoquée entre
        // temps, micro déjà accaparé par le système, etc.) : on ne laisse jamais ça remonter
        // et planter l'appli, on abandonne juste le passage en direct.
        val record = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize
            )
        } catch (e: Exception) {
            null
        }

        if (record == null || record.state != AudioRecord.STATE_INITIALIZED) {
            try { record?.release() } catch (_: Exception) {}
            toast("Impossible d'accéder au micro")
            return
        }

        RadioState.isVoiceLive = true
        RadioState.currentTrackName = "🎙️ Votre voix — EN DIRECT"
        RadioState.positionMs = 0L
        RadioState.durationMs = 0L

        // Sur Android 10+, le type "microphone" du service au premier plan doit être activé
        // explicitement au moment où le micro est réellement utilisé (sinon SecurityException
        // possible sur Android 14+). On protège cet appel : en cas de refus système, on
        // annule le passage en direct au lieu de laisser l'appli planter.
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    buildNotification("🎙️ Micro en direct"),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                )
            } else {
                updateNotification("🎙️ Micro en direct")
            }
        } catch (e: Exception) {
            RadioState.isVoiceLive = false
            RadioState.currentTrackName = "—"
            try { record.release() } catch (_: Exception) {}
            toast("Impossible de démarrer le direct micro")
            return
        }

        // On ne met plus la musique en pause : on baisse simplement son volume local
        // (le flux /stream envoyé aux auditeurs, lui, n'est pas touché ici — voir
        // PlayerPage.kt côté client, qui baisse son propre volume pendant le direct).
        try { localPlayer?.setVolume(DUCK_VOLUME, DUCK_VOLUME) } catch (_: Exception) {}

        audioRecord = record
        voiceThread = Thread {
            val buffer = ByteArray(2048)
            try {
                record.startRecording()
                while (shouldRun && RadioState.isVoiceLive) {
                    val read = record.read(buffer, 0, buffer.size)
                    if (read > 0) {
                        webServer?.broadcastVoice(buffer, read)
                        RadioState.positionMs += (read / 2L * 1000L) / 16000L
                    }
                }
            } catch (_: Exception) {
            } finally {
                try { record.stop() } catch (_: Exception) {}
                try { record.release() } catch (_: Exception) {}
                if (audioRecord === record) audioRecord = null
            }
        }.also { it.name = "LocalRadio-Voice"; it.start() }
    }

    private fun stopVoice() {
        if (!RadioState.isVoiceLive && audioRecord == null) return
        RadioState.isVoiceLive = false
        try { audioRecord?.stop() } catch (_: Exception) {}
        voiceThread?.interrupt()
        voiceThread = null
        audioRecord = null

        // On remet le volume local à fond tout de suite : le son de coupure éventuel
        // (ci-dessous) doit sortir à plein volume, pas au volume "fond sonore".
        try { localPlayer?.setVolume(1f, 1f) } catch (_: Exception) {}

        if (shouldRun) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(
                        NOTIFICATION_ID,
                        buildNotification("Diffusion en cours…"),
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                    )
                } else {
                    updateNotification("Diffusion en cours…")
                }
            } catch (e: Exception) {
                updateNotification("Diffusion en cours…")
            }

            // Son de coupure configuré (voir MainActivity / réglages "coupure" sur un
            // morceau) : joué une seule fois sur le flux normal (/stream), en interrompant
            // brièvement la piste en cours, puis la playlist reprend son cours normalement
            // (déjà en fond depuis le début du direct, donc rien de plus à faire après).
            val outroTrackId = PlaylistManager.getOutroVoiceTrackId(this)
            val outroTrack = outroTrackId?.let { id -> PlaylistManager.load(this).find { it.id == id } }
            if (outroTrack != null && shouldRun) {
                Thread {
                    RadioState.isIntroPlaying = true
                    playTrackAndBroadcast(outroTrack, allowInterruptByIntro = false)
                    RadioState.isIntroPlaying = false
                }.also { it.name = "LocalRadio-VoiceOutro"; it.start() }
            }
        }
    }

    private fun sleepQuiet(ms: Long) {
        try { Thread.sleep(ms) } catch (_: InterruptedException) {}
    }

    /** Toast.makeText().show() exige un thread avec Looper (le thread principal) :
     * ce helper permet de l'appeler sans risque même depuis un thread d'arrière-plan
     * (ex. le thread qui joue une intro avant de démarrer le direct micro). */
    private fun toast(message: String) {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun acquireLocks() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LocalRadio::BroadcastLock")
        wakeLock?.acquire(12 * 60 * 60 * 1000L) // 12h max par sécurité

        val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        wifiLock = wifiManager.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "LocalRadio::WifiLock")
        wifiLock?.acquire()
    }

    private fun releaseLocks() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
        try { if (wifiLock?.isHeld == true) wifiLock?.release() } catch (_: Exception) {}
        wifiLock = null
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, LocalRadioApp.CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(text: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
            manager.notify(NOTIFICATION_ID, buildNotification(text))
        }
    }

    companion object {
        const val ACTION_START = "com.localradio.app.action.START"
        const val ACTION_STOP = "com.localradio.app.action.STOP"
        const val ACTION_START_VOICE = "com.localradio.app.action.START_VOICE"
        const val ACTION_STOP_VOICE = "com.localradio.app.action.STOP_VOICE"
        const val EXTRA_PORT = "extra_port"
        private const val NOTIFICATION_ID = 1001
        /** Volume de la musique locale pendant le direct micro (0f à 1f) : fond sonore discret. */
        private const val DUCK_VOLUME = 0.18f

        fun start(context: Context, port: Int) {
            val intent = Intent(context, RadioService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_PORT, port)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun startVoice(context: Context) {
            val intent = Intent(context, RadioService::class.java).apply { action = ACTION_START_VOICE }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
        }

        fun stopVoice(context: Context) {
            val intent = Intent(context, RadioService::class.java).apply { action = ACTION_STOP_VOICE }
            context.startService(intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, RadioService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
