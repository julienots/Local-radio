package com.localradio.app

/**
 * État partagé entre le WebServer (lecture, pour /status et la page web) et le
 * RadioService (écriture, pendant la diffusion). Egalement lu par MainActivity
 * pour rafraîchir l'UI par polling léger. Toutes les propriétés sont @Volatile
 * pour être visibles de façon cohérente entre threads sans synchronisation lourde.
 */
object RadioState {
    @Volatile var isRunning: Boolean = false
    @Volatile var isVoiceLive: Boolean = false
    @Volatile var stationName: String = "LocalRadio"
    @Volatile var currentTrackName: String = "—"
    @Volatile var currentMimeType: String = "audio/mpeg"
    @Volatile var positionMs: Long = 0L
    @Volatile var durationMs: Long = 0L
    @Volatile var listenerCount: Int = 0
    @Volatile var port: Int = 8080
    @Volatile var localIp: String = ""
    @Volatile var isIntroPlaying: Boolean = false

    fun reset() {
        isRunning = false
        currentTrackName = "—"
        positionMs = 0L
        durationMs = 0L
        listenerCount = 0
        isVoiceLive = false
        isIntroPlaying = false
    }
}
